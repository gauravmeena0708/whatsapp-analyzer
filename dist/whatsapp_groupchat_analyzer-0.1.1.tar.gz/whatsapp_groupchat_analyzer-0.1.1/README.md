# Introduction

This is second repo for whatsapp group analyzer. The complete usage example is given in examples/usage1.py

## How to run

    pip install -r requirements.txt
    cd examples
    python usage1.py

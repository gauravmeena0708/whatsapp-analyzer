# whatsapp_analyzer/__init__.py
# You can add any package-level initialization here if needed.
# For example, downloading NLTK data:
import nltk
nltk.download('stopwords', quiet=True)